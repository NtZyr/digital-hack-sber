clear_characters = {
    r'\n', 
    r'\r', 
    '\\', 
    '(', 
    ')', 
    ':'
}